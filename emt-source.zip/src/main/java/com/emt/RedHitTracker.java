package com.emt;

import net.minecraft.util.Util;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Remembers when each player was last hit, so the red tint
 * can last longer than vanilla's very short hurt flash.
 */
public final class RedHitTracker {
    /** How long (in milliseconds) a player stays red after being hit. */
    public static final long RED_DURATION_MS = 1000L;

    private static final Map<UUID, Long> LAST_HIT = new HashMap<>();

    private RedHitTracker() {
    }

    public static void markHit(UUID id) {
        LAST_HIT.put(id, Util.getMeasuringTimeMs());
    }

    public static boolean isRed(UUID id) {
        Long time = LAST_HIT.get(id);
        if (time == null) {
            return false;
        }
        if (Util.getMeasuringTimeMs() - time > RED_DURATION_MS) {
            LAST_HIT.remove(id);
            return false;
        }
        return true;
    }
}
