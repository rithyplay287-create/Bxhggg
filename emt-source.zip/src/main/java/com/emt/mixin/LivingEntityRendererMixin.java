package com.emt.mixin;

import com.emt.RedHitTracker;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(
        method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
        at = @At("TAIL")
    )
    private void emt$redOnHit(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (!(entity instanceof PlayerEntity)) {
            return;
        }

        // hurtTime > 0 means the player has just taken damage
        if (entity.hurtTime > 0) {
            RedHitTracker.markHit(entity.getUuid());
        }

        // Force the vanilla red hurt overlay while the timer is active
        if (RedHitTracker.isRed(entity.getUuid())) {
            state.hurt = true;
        }
    }
}
