package com.emt;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EmtMod implements ClientModInitializer {
    public static final String MOD_ID = "emt";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Emt loaded: players will turn red when hit.");
    }
}
